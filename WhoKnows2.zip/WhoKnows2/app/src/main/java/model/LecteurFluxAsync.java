package model;

import android.os.AsyncTask;
import android.os.Environment;
import android.util.Log;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.whoknows2.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.MalformedInputException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static android.os.FileUtils.copy;

public class LecteurFluxAsync extends AsyncTask<String, Void, JSONArray> {

    /* variable */

    private AppCompatActivity mActivity;
    private String mArticlesString;
    private String mArticles = "Articles.JSON";
    private File mArticlesFile;

    /* constructeur */

    public LecteurFluxAsync(AppCompatActivity activity, String chemin){
        mActivity = activity;
        mArticlesString = "bonjour";
        mArticles = chemin;
    }

    protected JSONArray doInBackground(String... params) {

        /*URL url = null;
        HttpURLConnection urlConnection = null;*/
        JSONArray result = null;
        /*try {

            String PRENOM = "hey.txt";
            FileInputStream input = openFileInput(PRENOM);
            FileInputStream json_article_file = new FileInputStream("Articles.JSON");
            InputStream in = new BufferedInputStream(json_article_file); // Stream

            mArticlesString = readStream(in);

            /*ByteArrayOutputStream baos = new ByteArrayOutputStream();
            copy (input, baos);
            mArticlesString = baos.toString();*/

            /*JSONObject objectJSON = new JSONObject(mArticlesString);

            result = objectJSON.getJSONArray("articles");
            Log.d("ok", "coool");

        }
        catch (MalformedURLException e) {
            Log.d("erreur1", "mauvaise URL");
            e.printStackTrace(); }
        catch (IOException e) {
            Log.d("erreur2", "mauvaise connection");
            e.printStackTrace();
        }
        catch (JSONException e){
            Log.d("erreur3", "PB JSON");
            e.printStackTrace();
        }
        finally {
            /*if (urlConnection != null)
                urlConnection.disconnect();
        }*/

        return result; // returns the result
    }

    protected void onPreExecute() {
        super.onPreExecute();
        //mActivity.setContentView(R.layout.loading_page);
    }

    protected void onProgressUpdate(Void... values) {
        super.onProgressUpdate(values);
    }

    protected void onPostExecute(JSONArray articlesJSON) {
        mActivity.setContentView(R.layout.activity_main);
        TextView mTextinit = (TextView) mActivity.findViewById(R.id.main_JSONtxt);
        mTextinit.setText(this.getArticlesString());
    }

    private String readStream(InputStream is) throws IOException {

        StringBuilder sb = new StringBuilder();
        BufferedReader r = new BufferedReader(new InputStreamReader(is),1000);
        int i = 0;
        for (String line = r.readLine(); line != null; line =r.readLine()){
            sb.append(line);
            Log.i("ça avance", "ligne n°"+i);
        }
        is.close();

        //Log.i("CIO", jsonextracted);
        Log.d("readstream", "heyeheyeheyeheyeheyeh");
        return sb.toString();

    }

    public String getArticlesString() {
        return mArticlesString;
    }
}
