package model;

import java.util.ArrayList;

public class FluxArticle {

    private String _status;
    private int _totalResult;
    private ArrayList<Article> _articlesArray;


}
