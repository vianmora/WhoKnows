package com.example.whoknows2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Environment;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import model.LecteurFluxAsync;

public class MainActivity extends AppCompatActivity {

    /* variables */
    private LecteurFluxAsync mLecteurFlux;
    private RequestQueue mRequestQueue;
    private String mArticles = "Articles.JSON";
    private File mArticlesFile;
    private String mUrlSources_str = "https://newsapi.org/v2/sources?apiKey=d31f5fa5f03443dd8a1b9e3fde92ec34&language=fr";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String mChemin = Environment.getExternalStorageDirectory().getPath() + "/Android/data/" + getPackageName() + "/files/" + mArticles;

        mArticlesFile = new File(mChemin);

        ecrire(mArticles, "Salut");

        mLecteurFlux = new LecteurFluxAsync(MainActivity.this, mChemin);
        mLecteurFlux.execute(mUrlSources_str);

    }

    private void ecrire (String chemin, String text){
        try {
            // Flux interne
            FileOutputStream output = openFileOutput(chemin, MODE_PRIVATE);

            // On écrit dans le flux interne
            output.write(text.getBytes());

            if(output != null)
                output.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
